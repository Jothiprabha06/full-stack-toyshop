import { Link } from 'react-router-dom';
import './toy4.css';
import k1 from './assests/pp1.jpeg';
const Toy4= () => {
    return (
        
             <div>
             <a href ="https://youtu.be/lNLmk7CPtOw"><img src={k1} alt="" className="apple"></img></a>
             <h1 className="apple1">TOY DESCRIPTION</h1>
             <h5 className="apple10">RATING:4.8★</h5>
             <p className="apple2">ITEM DESCRIPTIONS/INFORMATION:Title: 8" CK Polar Bear Plush Stuffed Animal Toy - NewConditon:Brand New.Details:Measures 8" (Sizes are approximate.)Great item for a gift.Perfect for Collectors.Manufacturers suggested age 3+All items are of high quality.SHI.</p>
            <h1 className="apple3">KEY FEATURES</h1>
            <p className="apple2">CHARACTER:Polar Bear</p>
            <p className="apple2">AGE: 1Years</p> 
            <p className="apple2">FILLING MATERIAL:Fiber</p>
            <p className="apple2">WASHABLE:Yes</p> 
            <p className="apple2">SOUND SUPPORT:No</p>
            <p className="apple2">WIDTH:15cm</p>
            <p className="apple2">HEIGHT:10cm</p>
            <p className="apple2">WEIGHT:450g</p>
            <p className="apple2">COUNTRY OF ORIGIN:India</p> 
           
             </div>
             )
             }
 export default Toy4;