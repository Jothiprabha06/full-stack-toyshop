import { Link } from 'react-router-dom';
import './toy2.css';
import k1 from './assests/u1.jpeg';
const Toy2= () => {
    return (
        
             <div>
             <a href ="https://youtu.be/lNLmk7CPtOw"><img src={k1} alt="" className="apple"></img></a>
             <h1 className="apple1">TOY DESCRIPTION</h1>
             <h5 className="apple10">RATING:4.5★</h5>
             <p className="apple2">
             Soft Toys are crafted with perfection using the finest materials, Non-toxic and soft fabric Soft and Cuddly filling Home Washable Hug-gable and love-able for someone special. Delight your little ones this year by presenting them with an adorable soft toy. This soft toy into their bedroom will give them endless hours of fun-filled playtime. Recommended Age Group: 1+ Yrs.</p>
            <h1 className="apple3">KEY FEATURES</h1>
            <p className="apple2">CHARACTER:Unicorn Teddy</p>
            <p className="apple2">AGE:6+Months</p> 
            <p className="apple2">FILLING MATERIAL:Cotton,Fabric</p>
            <p className="apple2">WASHABLE:Yes</p> 
            <p className="apple2">SOUND SUPPORT:No</p>
            <p className="apple2">WEIGHT:200g</p>
            <p className="apple2">COUNTRY OF ORIGIN:India</p> 
           
             </div>
             )
             }
 export default Toy2;